import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-plantillalogin',
  templateUrl: './plantillalogin.component.html',
  styleUrls: ['./plantillalogin.component.css']
})
export class PlantillaloginComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
